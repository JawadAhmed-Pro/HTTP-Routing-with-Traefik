db.messages.insertMany([
  { message: "Welcome to the Docker World .. Jawad Ahmed apka suhagat krty hein !" },
  { message: "We're whaley glad you're here!" },
  { message: "Whale, whale, whale, what have we here?" },
  { message: "hello there!" },
  { message: "So nice to see you!" },
  { message : "Let's play some games to have with you ."},
  { message : "Paper m Cloud Fedration wala question nai parha tha mam ."},
]);